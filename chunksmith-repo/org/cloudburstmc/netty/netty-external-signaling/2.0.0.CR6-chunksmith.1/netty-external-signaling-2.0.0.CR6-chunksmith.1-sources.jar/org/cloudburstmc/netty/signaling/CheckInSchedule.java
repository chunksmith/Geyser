/*
 * Copyright 2026 CloudburstMC
 *
 * CloudburstMC licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package org.cloudburstmc.netty.signaling;

import com.google.gson.JsonObject;

import java.io.IOException;

/**
 * Validates the scheduling contract; policy and idle thresholds belong to the provider.
 */
record CheckInSchedule(long afterMillis, long leaseMillis, long minUpdateIntervalMillis) {
    static CheckInSchedule parse(JsonObject response) throws IOException {
        try {
            JsonObject checkIn = response.getAsJsonObject("checkIn");
            long after = number(checkIn, "afterMillis"), lease = number(checkIn, "leaseMillis"),
                    minimum = number(checkIn, "minUpdateIntervalMillis");
            if (after < 1000 || after > 86400000 || minimum < 1000 || minimum > after
                    || lease <= after || lease - after > 300000) {
                throw new IllegalArgumentException();
            }

            return new CheckInSchedule(after, lease, minimum);
        } catch (RuntimeException invalid) {
            throw new IOException("Invalid provider check-in schedule", invalid);
        }
    }

    private static long number(JsonObject object, String field) {
        var value = object.getAsJsonPrimitive(field);
        if (!value.isNumber()) {
            throw new IllegalArgumentException();
        }
        return value.getAsBigDecimal().longValueExact();
    }
}
