/*
 * Copyright 2026 CloudburstMC
 *
 * CloudburstMC licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package org.cloudburstmc.netty.signaling.provider;

import io.netty.util.NetUtil;
import org.cloudburstmc.netty.util.nethernet.EndpointAddress;

import java.io.IOException;
import java.net.*;
import java.util.*;

/**
 * Bound addresses plus operator-provisioned forwarding endpoints. Discovery never guesses NAT mappings.
 */
record ProviderEndpoint(InetSocketAddress bind, List<InetSocketAddress> advertised) {
    public static ProviderEndpoint resolve(InetSocketAddress bind, List<InetSocketAddress> external, boolean localDevelopment) throws IOException {
        if (bind.isUnresolved()) throw new IOException("Provider bind-address could not be resolved");
        return resolve(bind, external, localDevelopment, bind.getAddress().isAnyLocalAddress() ? interfaces() : List.of());
    }

    /**
     * Only the configured endpoints, for a host players reach through PROXY protocol relays, which these
     * name. The host's own addresses stay out, as nothing reaches them directly.
     */
    public static ProviderEndpoint relayed(InetSocketAddress bind, List<InetSocketAddress> external, boolean localDevelopment) throws IOException {
        checkBind(bind);
        return relayed(bind, external, localDevelopment, bind.getAddress().isAnyLocalAddress() ? interfaces() : List.of());
    }

    static ProviderEndpoint relayed(InetSocketAddress bind, List<InetSocketAddress> external, boolean localDevelopment,
                                    List<InetAddress> interfaces) throws IOException {
        checkBind(bind);
        Set<InetSocketAddress> endpoints = configured(external, localDevelopment);
        if (endpoints.isEmpty()) {
            throw new IOException("No UDP endpoints; configure nxs.advertise-addresses naming the PROXY protocol relays");
        }
        for (InetSocketAddress endpoint : endpoints) {
            InetAddress address = endpoint.getAddress();
            boolean local = bind.getAddress().isAnyLocalAddress()
                    ? address.isLoopbackAddress() || interfaces.contains(address) : address.equals(bind.getAddress());
            if (local && endpoint.getPort() == bind.getPort()) {
                throw new IOException(NetUtil.toSocketAddressString(endpoint) + " is this host's own gameplay endpoint, "
                        + "which players only reach through the PROXY protocol relays");
            }
        }
        return sorted(bind, endpoints);
    }

    static ProviderEndpoint resolve(InetSocketAddress bind, List<InetSocketAddress> external, boolean localDevelopment,
                                    List<InetAddress> interfaces) throws IOException {
        checkBind(bind);
        Set<InetSocketAddress> endpoints = configured(external, localDevelopment);
        if (!bind.getAddress().isAnyLocalAddress()) {
            // A local proxy may forward a configured external endpoint to a loopback listener.
            if (EndpointAddress.advertisable(bind.getAddress(), localDevelopment)) {
                InetAddress unscoped = InetAddress.getByAddress(bind.getAddress().getAddress());
                endpoints.add(new InetSocketAddress(unscoped, bind.getPort()));
            }
        } else {
            for (InetAddress address : interfaces) {
                // The pinned native listener uses IPV6_V6ONLY=0 for ::. A 0.0.0.0 socket is IPv4 only.
                if (!address.isLoopbackAddress() && EndpointAddress.advertisable(address, localDevelopment)
                        && (!(bind.getAddress() instanceof Inet4Address) || address instanceof Inet4Address)) {
                    InetAddress unscoped = InetAddress.getByAddress(address.getAddress());
                    endpoints.add(new InetSocketAddress(unscoped, bind.getPort()));
                }
            }
        }

        if (endpoints.isEmpty()) {
            throw new IOException("No usable UDP endpoints; configure nxs.advertise-addresses for external forwarding");
        }
        return sorted(bind, endpoints);
    }

    private static void checkBind(InetSocketAddress bind) throws IOException {
        if (bind.isUnresolved() || bind.getPort() < 1 || bind.getAddress().isMulticastAddress()) {
            throw new IOException("Provider bind-address must resolve to a local unicast or wildcard address and fixed UDP port");
        }
    }

    private static Set<InetSocketAddress> configured(List<InetSocketAddress> external, boolean localDevelopment) throws IOException {
        Set<InetSocketAddress> endpoints = new LinkedHashSet<>();
        // Configured mappings are explicit assertions about the forwarder, which may translate IP families.
        for (InetSocketAddress endpoint : external) {
            if (endpoint.isUnresolved() || endpoint.getPort() < 1 || !EndpointAddress.advertisable(endpoint.getAddress(), localDevelopment)) {
                throw new IOException("Advertised endpoint must be a usable numeric unicast IP and UDP port");
            }

            endpoints.add(endpoint);
        }
        return endpoints;
    }

    private static ProviderEndpoint sorted(InetSocketAddress bind, Set<InetSocketAddress> endpoints) throws IOException {
        if (endpoints.size() > 32) {
            throw new IOException("More than 32 UDP endpoints; bind to a specific address to limit interface discovery");
        }

        List<InetSocketAddress> sorted = endpoints.stream().sorted(Comparator
                .comparingInt(ProviderEndpoint::rank)
                .thenComparing(endpoint -> endpoint.getAddress().getHostAddress())
                .thenComparingInt(InetSocketAddress::getPort)).toList();
        return new ProviderEndpoint(bind, sorted);
    }

    public List<String> warnings() {
        List<String> messages = new ArrayList<>();
        if (advertised.stream().noneMatch(endpoint -> EndpointAddress.scope(endpoint.getAddress()) == EndpointAddress.Scope.PUBLIC)) {
            messages.add("Only private/shared or local addresses are advertised. Clients need LAN, VPN or routed connectivity to these endpoints. External signaling providers may advertise them; Warden does not relay game traffic.");
        }

        if (advertised.stream().allMatch(endpoint -> endpoint.getAddress() instanceof Inet6Address)) {
            messages.add("Only IPv6 endpoints are advertised. Clients without working IPv6 connectivity to this host cannot join. Configure a reachable IPv4 endpoint for IPv4 clients.");
        }

        return List.copyOf(messages);
    }

    private static int rank(InetSocketAddress endpoint) {
        return (EndpointAddress.scope(endpoint.getAddress()) == EndpointAddress.Scope.PUBLIC ? 0 : 2)
                + (endpoint.getAddress() instanceof Inet6Address ? 0 : 1);
    }

    private static List<InetAddress> interfaces() throws IOException {
        List<InetAddress> addresses = new ArrayList<>();
        var interfaces = NetworkInterface.getNetworkInterfaces();
        if (interfaces == null) return addresses;

        for (NetworkInterface network : Collections.list(interfaces)) {
            if (network.isUp() && !network.isLoopback()) addresses.addAll(Collections.list(network.getInetAddresses()));
        }

        return addresses;
    }
}
