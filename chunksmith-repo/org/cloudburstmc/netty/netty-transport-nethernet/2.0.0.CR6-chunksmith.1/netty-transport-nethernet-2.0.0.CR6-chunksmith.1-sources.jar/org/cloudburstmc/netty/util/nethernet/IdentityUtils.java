/*
 * Copyright 2026 CloudburstMC
 *
 * CloudburstMC licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package org.cloudburstmc.netty.util.nethernet;

import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;
import org.jose4j.jwk.HttpsJwks;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.jwt.consumer.JwtContext;
import org.jose4j.keys.resolvers.HttpsJwksVerificationKeyResolver;
import org.jose4j.lang.JoseException;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.stream.Collectors;

public class IdentityUtils {
    private static final InternalLogger log = InternalLoggerFactory.getInstance(IdentityUtils.class);

    private static final HttpsJwks JWKS =
            new HttpsJwks("https://authorization.franchise.minecraft-services.net/.well-known/keys");
    private static final JwtConsumer JWT_CONSUMER = new JwtConsumerBuilder()
            .setVerificationKeyResolver(new HttpsJwksVerificationKeyResolver(JWKS))
            .setRequireExpirationTime()
            .setRequireSubject()
            .setExpectedAudience(true, "api://auth-minecraft-services/multiplayer")
            .setExpectedIssuer("https://authorization.franchise.minecraft-services.net/")
            .build();

    /**
     * Fetches the auth service's keys ahead of the first join, so that join does not pay for the
     * round trip. A failure is only logged: the first join fetches them again.
     */
    public static void prefetchKeys() {
        try {
            JWKS.refresh();
        } catch (Exception e) {
            log.warn("Could not prefetch the Minecraft auth keys, the first join will fetch them: {}", e.toString());
        }
    }

    /**
     * Validate the given identity against the known jwt signer
     *
     * @param identity The identity to validate
     * @return The JWT context if the identity is valid
     * @throws InvalidJwtException If the identity is invalid
     */
    /**
     * @param key An EC public key
     * @return The key as a token's {@code cpk} claim carries it, base64 of its X.509 encoding
     */
    public static String encodePublicKey(PublicKey key) {
        return Base64.getEncoder().encodeToString(key.getEncoded());
    }

    /**
     * @param encoded A key as {@link #encodePublicKey} writes it
     * @return The key
     * @throws GeneralSecurityException If the bytes are not an EC public key
     */
    public static PublicKey decodePublicKey(String encoded) throws GeneralSecurityException {
        byte[] der = Base64.getDecoder().decode(encoded);
        return KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(der));
    }

    public static JwtContext validateIdentity(Identity identity) throws InvalidJwtException {
        return JWT_CONSUMER.process(identity.assertion().token()); // TODO Take into account the idp in the identity
    }

    /**
     * Validate the SDP offer against the embedded identity and known jwt signer
     * This is designed into the spec to prevent MITM
     *
     * @param sdpOffer The SDP offer to validate
     * @return The JWT claims if the SDP offer is valid
     * @throws JoseException       If there is an error processing the SDP offer
     * @throws InvalidJwtException If the SDP offer contains an invalid JWT
     */
    public static JwtClaims validateSdp(String sdpOffer) throws JoseException, InvalidJwtException {
        return validateSdp(sdpOffer, TokenTrust.MINECRAFT_AUTH);
    }

    /**
     * Validate the SDP offer against the embedded identity, trusting its token as {@code trust}
     * decides. The fingerprint binding is checked either way.
     *
     * @param sdpOffer The SDP offer to validate
     * @param trust    Who to trust to have signed the token
     * @return The JWT claims if the SDP offer is valid
     * @throws JoseException       If there is an error processing the SDP offer
     * @throws InvalidJwtException If the SDP offer contains an invalid JWT
     */
    public static JwtClaims validateSdp(String sdpOffer, TokenTrust trust)
            throws JoseException, InvalidJwtException {
        // Extract the identity
        Identity identity = Identity.fromSdpOffer(sdpOffer);
        if (identity == null) {
            throw new JoseException("Invalid SDP offer: missing identity");
        }
        log.debug("Received identity: " + identity);

        JwtClaims claims;
        try {
            claims = trust.claims(identity);
        } catch (InvalidJwtException | JoseException e) {
            throw e;
        } catch (Exception e) {
            throw new JoseException("Token is not trusted", e);
        }

        // Reconstruct the detached payload from the SDP fingerprint lines
        String fingerprints = getCanonicalFingerprintJson(sdpOffer);
        if (fingerprints.length() == 18) { // Check if it is just the empty array {"fingerprint":[]}
            throw new JoseException("Invalid SDP offer: no fingerprints");
        }

        // Validate the detached fingerprints JWS against the cpk from the token
        String detachedJws = identity.assertion().fingerprints();
        try {
            JsonWebSignature jws = new JsonWebSignature();
            jws.setCompactSerialization(detachedJws);

            PublicKey cpkKey = decodePublicKey(claims.getClaimValueAsString("cpk"));

            // Set the JWS properties so we can verify
            jws.setKey(cpkKey);
            jws.setPayload(fingerprints);
            jws.setAlgorithmConstraints(new AlgorithmConstraints(ConstraintType.PERMIT,
                    AlgorithmIdentifiers.ECDSA_USING_P384_CURVE_AND_SHA384));

            if (!jws.verifySignature()) {
                throw new JoseException("Fingerprint signature mismatch");
            }
        } catch (GeneralSecurityException e) {
            throw new JoseException("Fingerprint JWS validation failed", e);
        }

        return claims;
    }

    /**
     * Get the canonical fingerprint JSON from the SDP offer
     *
     * @param sdpOffer The SDP offer to extract fingerprints from
     * @return The canonical fingerprint JSON
     */
    public static String getCanonicalFingerprintJson(String sdpOffer) {
        String prefix = "a=fingerprint:";
        return Arrays.stream(sdpOffer.split("\n"))
                .filter(line -> line.startsWith(prefix))
                .map(line -> line.substring(prefix.length()).trim())
                .map(line -> {
                    String[] parts = line.split(" ");
                    if (parts.length != 2) {
                        throw new IllegalArgumentException("Invalid fingerprint line: " + line);
                    }
                    return "{\"algorithm\":\"" + parts[0] + "\",\"digest\":\"" + parts[1] + "\"}";
                })
                .collect(Collectors.joining(",", "{\"fingerprint\":[", "]}"));
    }
}
