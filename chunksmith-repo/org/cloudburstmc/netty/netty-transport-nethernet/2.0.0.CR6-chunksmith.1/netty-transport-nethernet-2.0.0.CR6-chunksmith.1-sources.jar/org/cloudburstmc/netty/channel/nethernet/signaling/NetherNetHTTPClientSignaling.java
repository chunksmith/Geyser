/*
 * Copyright 2026 CloudburstMC
 *
 * CloudburstMC licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package org.cloudburstmc.netty.channel.nethernet.signaling;

import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;
import org.cloudburstmc.netty.channel.nethernet.NetherNetConstants;
import org.cloudburstmc.netty.channel.nethernet.signaling.HttpSignalingSettings.Scheme;
import org.jspecify.annotations.Nullable;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.ConnectException;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

import javax.net.ssl.SSLException;
import java.util.List;
import java.util.StringJoiner;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;

/**
 * The client half of HTTP signaling: connects out to a server's {@code /v1/join} endpoint, as a
 * proxy does toward a downstream server. One instance serves one connection.
 * <p>
 * HTTP signaling is a single request and response, so there is no trickle: the channel gathers
 * every candidate first and hands the finished offer to {@link #sendDescription}, and the answer
 * comes back through the signal handler like any other. The offer's identity assertion is the
 * channel's business too, through {@code NetherChannelOption.NETHER_CLIENT_IDENTITY}.
 * <p>
 * By default it does what the retail client does: probes the endpoint over HTTPS, falls back to
 * plaintext when there is no TLS, and posts the offer over whichever answered. HTTPS validates the
 * certificate against the JDK trust store, or the one in the settings, and the host name of the
 * address it was given, so a server behind a certificate has to be addressed by name. A server
 * serving TLS refuses plaintext by default. {@link HttpSignalingSettings} fixes the scheme instead.
 * <p>
 * Nothing here runs on the channel's loop, the channel moves itself back onto it.
 */
public class NetherNetHTTPClientSignaling implements NetherNetClientSignaling {
    private static final InternalLogger log = InternalLoggerFactory.getInstance(NetherNetHTTPClientSignaling.class);

    private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(10);

    /** How much of a refusal's body is worth carrying into an exception message. */
    private static final int REASON_LIMIT = 200;

    private final String localNetworkId;
    private final HttpSignalingSettings settings;
    private volatile boolean secure;

    private volatile InetSocketAddress address;
    private volatile String connectionId;
    private volatile SignalHandler handler;
    private volatile FailureHandler failure;
    private volatile boolean closed;

    /** Signals as {@link HttpSignalingSettings#DEFAULT} says, with a random network id. */
    public NetherNetHTTPClientSignaling() {
        this(HttpSignalingSettings.DEFAULT);
    }

    /** Signals as the settings say, with a random network id. */
    public NetherNetHTTPClientSignaling(HttpSignalingSettings settings) {
        this(settings, Long.toUnsignedString(ThreadLocalRandom.current().nextLong()));
    }

    /** Signals as the settings say, with the given network id. */
    public NetherNetHTTPClientSignaling(HttpSignalingSettings settings, String localNetworkId) {
        this.settings = settings;
        this.localNetworkId = localNetworkId;
    }

    /**
     * What a probe found: the scheme that answered and the status the server advertises.
     *
     * @param scheme {@link Scheme#HTTPS} or {@link Scheme#HTTP}, never {@link Scheme#AUTO}
     * @param motd   The status the server sent, or null when it sent none, as vanilla BDS does
     */
    public record Probe(Scheme scheme, @Nullable PongData motd) {
    }

    /**
     * As {@link #probe(InetSocketAddress, HttpSignalingSettings, String)}, sending no network id.
     */
    public static CompletableFuture<Probe> probe(InetSocketAddress address, HttpSignalingSettings settings) {
        return probe(address, settings, null);
    }

    /**
     * Asks the endpoint whether it serves NetherNet, the way the settings say, which for
     * {@link Scheme#AUTO} is HTTPS first and plaintext when the host answered without TLS. A host
     * that does not answer fails at once. A server that does not serve NetherNet answers 404, which
     * fails the probe and is what drives a fallback to RakNet.
     *
     * @param address   The server's signaling endpoint
     * @param settings  How to reach it
     * @param networkId The network id the client will join as, or null to send none
     * @return The scheme that answered and the server's status, or a failure saying why not
     */
    public static CompletableFuture<Probe> probe(InetSocketAddress address, HttpSignalingSettings settings,
                                                 @Nullable String networkId) {
        String query = query(settings.clientInfo(), networkId);
        return switch (settings.scheme()) {
            case HTTPS -> get(address, true, query, settings)
                    .thenApply(response -> probed(address, response, Scheme.HTTPS, null));
            case HTTP -> get(address, false, query, settings)
                    .thenApply(response -> probed(address, response, Scheme.HTTP, null));
            case AUTO -> get(address, true, query, settings).handle((response, error) -> {
                if (error == null) {
                    // An answer over HTTPS is final, whatever it says
                    return CompletableFuture.completedFuture(probed(address, response, Scheme.HTTPS, null));
                }
                Throwable cause = unwrap(error);
                if (!(cause instanceof SSLException)) {
                    // Nothing answered, so plaintext would only wait through the same failure again
                    throw refused(address + " could not be reached: " + describe(cause));
                }
                // Something answered and it was not TLS, which is the one case plaintext is for
                return get(address, false, query, settings)
                        .thenApply(fallback -> probed(address, fallback, Scheme.HTTP, cause));
            }).thenCompose(Function.identity());
        };
    }

    /** The probe's query, or empty when there is nothing to send. */
    private static String query(@Nullable ClientInfo info, @Nullable String networkId) {
        StringJoiner query = new StringJoiner("&", "?", "").setEmptyValue("");
        if (info != null) {
            info.addTo(query);
        }
        if (networkId != null) {
            query.add("id=" + URLEncoder.encode(networkId, StandardCharsets.UTF_8));
        }
        return query.toString();
    }

    private static CompletableFuture<HttpResponse<String>> get(InetSocketAddress address, boolean secure,
                                                               String query, HttpSignalingSettings settings) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl(address, secure) + "/v1/join" + query))
                .timeout(HTTP_TIMEOUT)
                .header("Accept", "application/json")
                .GET()
                .build();
        return settings.http().sendAsync(request, HttpResponse.BodyHandlers.ofString());
    }

    /**
     * Reads a probe's response into a result, or fails with the reason as a
     * {@link CompletionException} around a {@link ConnectException}, which the future unwraps.
     *
     * @param httpsFailure Why the HTTPS attempt before this plaintext one failed, when there was one
     */
    private static Probe probed(InetSocketAddress address, HttpResponse<String> response, Scheme scheme,
                                @Nullable Throwable httpsFailure) {
        int code = response.statusCode();
        if (code / 100 == 2) {
            String body = response.body();
            // Vanilla BDS answers with an empty body, and serves NetherNet all the same
            if (body == null || body.isBlank()) {
                return new Probe(scheme, null);
            }
            try {
                return new Probe(scheme, PongData.fromJson(body));
            } catch (IllegalArgumentException e) {
                throw refused(address + " answered the probe with something other than a NetherNet status");
            }
        }
        if (code == 404) {
            throw refused(address + " does not serve NetherNet (HTTP 404)");
        }
        if (code == 426) {
            throw refused(address + " requires TLS"
                    + (httpsFailure == null ? "" : ", and HTTPS failed: " + describe(httpsFailure)));
        }
        throw refused(address + " answered HTTP " + code + " to the probe" + reason(response.body()));
    }

    private static CompletionException refused(String message) {
        return new CompletionException(new ConnectException(message));
    }

    private static Throwable unwrap(Throwable error) {
        return error instanceof CompletionException && error.getCause() != null ? error.getCause() : error;
    }

    @Override
    public boolean usesTrickleIce() {
        return false;
    }

    @Override
    public CompletableFuture<List<IceServerInfo>> connect(SocketAddress remoteAddress) {
        if (this.closed) {
            // Otherwise the offer is posted and its answer dropped, which looks like a hang
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "This signaling already served a connection, create one per connection"));
        }
        if (!(remoteAddress instanceof InetSocketAddress endpoint)) {
            return CompletableFuture.failedFuture(
                    new IllegalArgumentException("HTTP signaling needs an InetSocketAddress, not " + remoteAddress));
        }
        this.address = endpoint;
        if (this.settings.scheme() != Scheme.AUTO) {
            this.secure = this.settings.scheme() == Scheme.HTTPS;
            return CompletableFuture.completedFuture(this.settings.iceServers());
        }
        return probe(endpoint, this.settings, this.localNetworkId).thenApply(probe -> {
            this.secure = probe.scheme() == Scheme.HTTPS;
            return this.settings.iceServers();
        });
    }

    @Override
    public void sendDescription(String targetNetworkId, String offer) {
        URI join = URI.create(baseUrl(this.address, this.secure) + "/v1/join/" + this.localNetworkId);
        HttpRequest request = HttpRequest.newBuilder(join)
                .timeout(HTTP_TIMEOUT)
                .header("Content-Type", "application/sdp")
                .header("Accept", "application/sdp")
                .POST(HttpRequest.BodyPublishers.ofString(offer))
                .build();

        this.settings.http().sendAsync(request, HttpResponse.BodyHandlers.ofString()).whenComplete(this::onAnswer);
    }

    private void onAnswer(HttpResponse<String> response, Throwable error) {
        if (this.closed) {
            return;
        }
        if (error != null) {
            this.fail("could not reach the signaling endpoint: " + describe(unwrap(error)));
            return;
        }
        if (response.statusCode() / 100 != 2) {
            this.fail(status(response) + reason(response.body()));
            return;
        }

        String answer = response.body();
        // A rejection can arrive as a 2xx with a short body instead of an SDP, so the shape has to
        // be checked rather than the status alone
        if (answer == null || !answer.startsWith("v=")) {
            this.fail(status(response) + " without an SDP answer" + reason(answer));
            return;
        }

        SignalHandler target = this.handler;
        if (target != null) {
            target.onSignal(NetherNetConstants.buildSignalConnectResponse(this.connectionId, answer));
        }
    }

    private void fail(String reason) {
        log.debug("Signaling to {} failed: {}", this.address, reason);
        FailureHandler target = this.failure;
        if (target != null) {
            target.onFailure(reason);
        }
    }

    /** The JDK client's exceptions often carry no message, so the type has to say what happened. */
    private static String describe(Throwable cause) {
        if (cause instanceof HttpConnectTimeoutException) {
            return "connect timed out";
        }
        if (cause instanceof HttpTimeoutException) {
            return "no response within " + HTTP_TIMEOUT.toSeconds() + " s";
        }
        if (cause instanceof ConnectException) {
            return "connection refused";
        }
        if (cause instanceof SSLException) {
            return "TLS failed, " + cause.getMessage();
        }
        return cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
    }

    private static String status(HttpResponse<?> response) {
        int code = response.statusCode();
        return "HTTP " + code + (code == 426 ? " (TLS required)" : "");
    }

    /**
     * The server's stated reason, fit for an exception message: the body is remote controlled, so
     * it is cut short and reduced to printable ASCII before it can reach a log.
     */
    private static String reason(String body) {
        if (body == null || body.isBlank()) {
            return "";
        }
        StringBuilder out = new StringBuilder(": ");
        for (int i = 0; i < body.length() && out.length() < REASON_LIMIT; i++) {
            char c = body.charAt(i);
            out.append(c >= ' ' && c <= '~' ? c : ' ');
        }
        return out.toString().stripTrailing();
    }

    private static String baseUrl(InetSocketAddress address, boolean secure) {
        // Plaintext uses the literal, so the URL triggers no lookup. TLS needs the name the
        // certificate is issued for, which is what the address carries when it was given one
        String host = secure || address.isUnresolved()
                ? address.getHostString() : address.getAddress().getHostAddress();
        return (secure ? "https://" : "http://") + (host.indexOf(':') >= 0 ? "[" + host + "]" : host)
                + ":" + address.getPort();
    }

    @Override
    public void setSignalHandler(String connectionId, SignalHandler handler) {
        // The answer is delivered as a signal for this id, the same way trickle signaling would
        this.connectionId = connectionId;
        this.handler = handler;
    }

    @Override
    public void removeSignalHandler(String connectionId) {
        if (connectionId.equals(this.connectionId)) {
            this.handler = null;
        }
    }

    @Override
    public void setFailureHandler(FailureHandler handler) {
        this.failure = handler;
    }

    @Override
    public String getLocalNetworkId() {
        return this.localNetworkId;
    }

    @Override
    public boolean isActive() {
        return !this.closed;
    }

    @Override
    public void close() {
        this.closed = true;
    }
}
