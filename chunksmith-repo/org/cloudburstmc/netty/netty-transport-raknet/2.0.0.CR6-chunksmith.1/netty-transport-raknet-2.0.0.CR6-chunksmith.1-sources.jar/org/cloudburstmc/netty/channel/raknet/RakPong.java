/*
 * Copyright 2022 CloudburstMC
 *
 * CloudburstMC licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package org.cloudburstmc.netty.channel.raknet;

import io.netty.buffer.ByteBuf;
import io.netty.util.AbstractReferenceCounted;
import io.netty.util.ReferenceCountUtil;

import java.net.InetSocketAddress;

public class RakPong extends AbstractReferenceCounted {

    private final long pingTime;
    private final long guid;
    private final ByteBuf pongData;
    private final InetSocketAddress sender;
    private final InetSocketAddress recipient;

    public RakPong(long pingTime, long guid, ByteBuf pongData, InetSocketAddress sender) {
        this(pingTime, guid, pongData, sender, null);
    }

    public RakPong(long pingTime, long guid, ByteBuf pongData, InetSocketAddress sender, InetSocketAddress recipient) {
        this.pingTime = pingTime;
        this.guid = guid;
        this.pongData = pongData;
        this.sender = sender;
        this.recipient = recipient;
    }

    public long getPingTime() {
        return this.pingTime;
    }

    public long getGuid() {
        return this.guid;
    }

    public ByteBuf getPongData() {
        return this.pongData;
    }

    public InetSocketAddress getSender() {
        return this.sender;
    }

    public InetSocketAddress getRecipient() {
        return this.recipient;
    }

    @Override
    protected void deallocate() {
        ReferenceCountUtil.release(this.pongData);
    }

    @Override
    public RakPong touch(Object hint) {
        if (pongData != null) {
            pongData.touch(hint);
        }
        return this;
    }
}
